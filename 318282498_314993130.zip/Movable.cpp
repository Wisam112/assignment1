#include "Movable.h"

Movable::Movable()
{
	T = Eigen::Transform<float, 3, Eigen::Affine>::Identity();
}

Eigen::Matrix4f Movable::MakeTrans()
{
	return T.matrix();
}

void Movable::MyTranslate(Eigen::Vector3f amt)
{
	//Eigen::Transform<float, 3, Eigen::Affine> F= T.inverse(Eigen::Affine);
	//T = F * T;
	T.pretranslate(amt);
	//F = F.inverse(Eigen::Affine);
	//T = T * F;
}
//angle in radians
void Movable::MyRotate(Eigen::Vector3f rotAxis, float angle)
{
	T.rotate(Eigen::AngleAxisf(angle, rotAxis));
}

void Movable::MyScale(Eigen::Vector3f amt)
{
	T.scale(amt);
}